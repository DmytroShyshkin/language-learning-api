﻿package com.dmytro.language_learning_api.mapper;

import com.dmytro.language_learning_api.dto.UsersDTO;
import com.dmytro.language_learning_api.model.Users;

public class UsersMapper {
    public UsersDTO toDto(Users user) {
        return new UsersDTO(
                user.getId(),
                user.getEmail(),
                user.getPassword(), // TODO: reemplazar por null
                user.getUsername()
        );
    }

    public Users toEntity(UsersDTO usersDTO) {
        return new Users(
                usersDTO.id(),
                usersDTO.email(),
                usersDTO.password(), // TODO: reemplazar por null
                usersDTO.username()
        );
    }
}
